import numpy as np
import pandas as pd
def ObjectToFloat(data, features):
    for feature in features:
        feature_keys   = data[feature].value_counts().index
        feature_values = np.arange(1, len(feature_keys) + 1)
        feature_dict = {}
        for i in range(len(feature_keys)):
            feature_dict[feature_keys[i]] = feature_values[i]
        data[feature] = data[feature].map(feature_dict)
    return data


def getObjectsFeaturesList(df):
    features_for_replace = []
    for f in df:
        if type(df.at[1, f]) == str:
            features_for_replace.append(f)
    return features_for_replace
    
def ExpToFloat(Value):
    return float('%.2f'%Value)
    
def ExpToInteger(Value):
    return int('%d'%Value)

def getOutliersLimitis(Q1, Q3):
    IQR  = Q3 - Q1
    high = Q3 + (1.5 * IQR)
    low  = Q1 - (1.5 * IQR)
    return (high, low)

def getMissingValues(df, perc=0):
    null_sum     = df.isna().sum().sort_values(ascending=False)
    rows_n       = df.shape[0]
    df_null_sum  = pd.DataFrame(
        {
            'Count'      : [null_sum[n] for n in null_sum.index],
            'Percentage' : [(null_sum[n] / rows_n)*100 for n in null_sum.index]
        },
        index=[n for n in null_sum.index]
    )
    df_null_sum = df_null_sum[df_null_sum['Percentage'] > perc]
    return df_null_sum

def getYearFromDate(date):
    return date.year

def getMonthFromDate(date):
    return date.month

def getDayNameFromDate(date):
    return date.strftime('%A')

